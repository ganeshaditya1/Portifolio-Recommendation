"""
    Copyright (c) 2013, Los Alamos National Security, LLC
    All rights reserved.
    Redistribution and use in source and binary forms, with or without modification, are permitted provided that the
    following conditions are met:
    * Redistributions of source code must retain the above copyright notice, this list of conditions and the following
      disclaimer.
    * Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the
      following disclaimer in the documentation and/or other materials provided with the distribution.
    * Neither the name of Los Alamos National Security, LLC nor the names of its contributors may be used to endorse or
      promote products derived from this software without specific prior written permission.
    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
    SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
    SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
    WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
    THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
"""

import inspect
import random
import featureGeneration as fg
from sknn.mlp import Regressor, Layer
import numpy as np

class ObjectiveFunctionInterface(object):

    """
        This interface must be implemented by you. This defines the objective function HS optimizes.
    """
    
    train_x, train_y, test_x, test_y  = fg.getData();
    def get_fitness(self, vector):
        """
            Return the objective function value given a solution vector containing each decision variable. In practice,
            vector should be a list of parameters.
            For example, suppose the objective function is (-(x^2 + (y+1)^2) + 4). A possible call to fitness may look like this:
            >>> print obj_fun.fitness([4, 7])
            -76
        """
	
        numHiddenLayers = vector[0]
        arr = np.array(vector)
        columnIndex = arr[1:].astype('bool')
	data2 = data[:, columnIndex]
        nn = Regressor(
                 layers=[
                    Layer("Rectifier", units=numHiddenLayers),
                    Layer("Linear")],
                 learning_rule = "adagrad")

        f = nn.fit(train_x, train_y)
        ui = f.predict(test_x)
        
        return np.sum((ui - np.transpose([test_y]))^2)
        

    def get_value(self, i, j=None):
        if(i == 0):
		return j + 10
	else:
		return j

    def get_index(self, i, v):
        if(i == 0):
		return v - 10
	else:
		return v


    def get_num_discrete_values(self, i):
        if(i == 0):
		return 21
	else:
		return 2

    def get_lower_bound(self, i):
	if(i == 0):
		return 10
	else:
		return 0

    def get_upper_bound(self, i):
        if(i == 0):
		return 30
	else:
		return 1

    def is_variable(self, i):
        if(i <= 40):
		return true

    def is_discrete(self, i):
        return true

    def get_num_parameters(self):
        return 40

    def use_random_seed(self):
        return false

    def get_random_seed(self):
        return 1

    def get_max_imp(self):
        return 10000

    def get_hmcr(self):
        return 0.95

    def get_par(self):
        return 0.3

    def get_hms(self):
        return 100

    def get_mpai(self):
        return 20

    def get_mpap(self):
        return 1

    def maximize(self):
        return false


if __name__ == '__main__':
    obj_fun = ObjectiveFunction()
    num_processes = 1
    num_iterations = 1  # because random_seed is defined, there's no point in running this multiple times
    results = harmony_search(obj_fun, num_processes, num_iterations)
    print('Elapsed time: {}\nBest harmony: {}\nBest fitness: {}'.format(results.elapsed_time, results.best_harmony, results.best_fitness))



